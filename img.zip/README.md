# Kadunud õppeainete kool

Liikmed: <br>
Thorleif Erik Wiking Larsson <br>
Rainis Toming <br>
Kadri Kaljo <br>
Hendrik Aksalu <br>
Kätlin Epelbaum <br>

Figma -  [https://www.figma.com/design/sK47yGM6rhOIZnFSgpu2gT/Untitled?node-id=0-1&node-type=canvas&t=AMQceGrlOt44uG5w-0](https://www.figma.com/design/vs66074OBWJlhSnF4wzV7y/Kadunud-%C3%95ppeainete-Kool?node-id=0-1&p=f&t=42GiH0qnC894hZbh-0)

<h1>Esimene päev 01.10.25</h1>
Tiimi tutvustus. Mõtlesime välja mida võiks teha. Valituks sai Kadunud Õppeainete Kool. Edasi tegime plaani,milline leht välja peaks nägema ja mis seal olema peaks. Alustasime figmas lehe tegemisega. Tahvli peale sai kirja pandud jooksvad mõtted. Githubis repo ja Thor hakkas koodima. <br>
 <br>

![20251001_140759](https://github.com/user-attachments/assets/7d73cca7-2e2b-4d69-8340-7bb47ddd8cf9) 

![20251001_140936_720](https://github.com/user-attachments/assets/9cb2f2a8-ac00-4710-9d53-ebac1b3e8433)



Ülesanded: <br>
Thor hakkas tegelema html-iga <br>
Rainis tutvub figmaga ja homme teeb koodi<br>
Kadri teeb figmat ja mõtleb ideid<br>
Hendrik dokumenteerib, joonistas tahvli peale plaani, logo<br>
Kätlin toimetab figmaga<br>

<h1>Teine päev 02.10.25</h1>

Vaatame kaugele me jõudnud oleme. Täiendame Figmat. Mäng. Mängu testimine. Rainis mängib mängu läbi. 
